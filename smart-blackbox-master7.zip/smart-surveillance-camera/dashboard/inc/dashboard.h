#ifndef __DASHBOARD_H__
#define __DASHBOARD_H__

#include <dlog.h>

#ifdef  LOG_TAG
#undef  LOG_TAG
#endif
#define LOG_TAG "DASHBOARD"


#endif
